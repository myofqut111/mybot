"""Fishbot patrol route executor."""
