"""Fishbot patrol route manager."""
